<?php

namespace ACA\ACF\Field;

interface MaxLength {

	/**
	 * @return int
	 */
	public function get_maxlength();

}