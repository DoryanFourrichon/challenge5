<?php

namespace ACA\ACF\Field;

interface PostTypeFilterable {

	/**
	 * @return array
	 */
	public function get_post_type();

}