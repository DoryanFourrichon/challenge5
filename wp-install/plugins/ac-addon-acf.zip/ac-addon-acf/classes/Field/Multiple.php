<?php

namespace ACA\ACF\Field;

interface Multiple {

	/**
	 * @return bool
	 */
	public function is_multiple();

}