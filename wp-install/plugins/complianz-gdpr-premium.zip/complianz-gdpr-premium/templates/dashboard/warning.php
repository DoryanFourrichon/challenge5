<span class='cmplz-progress-status cmplz-{status-class}'>{status}</span>
