<div class="item-footer">
	<div>
		<div class="cmplz-footer-contents">
			<div class="cmplz-legend"><?php echo cmplz_icon('bullet', 'success')?><span><?php _e("Validated", "complianz-gdpr")?></span></div>
			<div class="cmplz-legend"><?php echo cmplz_icon('sync', 'success')?><span><?php _e("Synchronized", "complianz-gdpr")?></span></div>
			<div class="cmplz-legend"><?php echo cmplz_icon('shortcode', 'success')?><span><?php _e("Shortcode", "complianz-gdpr")?></span></div>
		</div>
	</div>
</div>
