<div class="item-footer">
	<div>
		<div class="cmplz-footer-contents">
			{footer}
		</div>
	</div>
</div>
