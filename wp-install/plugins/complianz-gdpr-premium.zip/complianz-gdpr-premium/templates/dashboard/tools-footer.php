<div class="item-footer">
	<div>
		<div class="cmplz-footer-contents">
			<a class="button button-secondary" target="_blank" href="<?php echo apply_filters("cmplz_support_link",'https://wordpress.org/support/plugin/complianz-gdpr/')?>" ><?php _e("Support", "complianz-gdpr") ?></a>
			<a class="button button-secondary" href="<?php echo trailingslashit(cmplz_url).'system-status.php' ?>" ><?php _e("System Status", "complianz-gdpr") ?></a>
		</div>
	</div>
</div>
