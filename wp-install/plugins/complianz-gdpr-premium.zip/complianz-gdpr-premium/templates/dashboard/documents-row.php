<div class="cmplz-document cmplz-{status}">
	<div>{title}</div>
	<div>{page_exists}</div>
	<div>{sync_icon}</div>
	<div>{shortcode_icon}</div>
	<div>{generated}</div>
</div>
