
<div class="cmplz-categories cmplz-tcf">

	<div class="cmplz-category cmplz-statistics">
		<div class="cmplz-category-header">
			<div class="cmplz-title"><?php _e('Statistics', 'complianz-gdpr') ?></div>
			<div class='cmplz-always-active'></div>
			<p class="cmplz-description"></p>
		</div>
	</div>

	<div class="cmplz-category cmplz-marketing">
		<div class="cmplz-category-header">
			<div class="cmplz-title"><?php _e('Marketing', 'complianz-gdpr') ?></div>
			<div class='cmplz-always-active'></div>
			<p class="cmplz-description"></p>
		</div>
	</div>

	<div class="cmplz-category cmplz-features">
		<div class="cmplz-category-header">
			<div class="cmplz-title"><?php _e('Features', 'complianz-gdpr') ?></div>
			<div class='cmplz-always-active'><?php _e('Always active', 'complianz-gdpr') ?></div>
			<p class="cmplz-description"></p>
		</div>
	</div>

	<div class="cmplz-category cmplz-specialfeatures">
		<div class="cmplz-category-header">
			<div class="cmplz-title"></div>
			<div class='cmplz-always-active'></div>
		</div>
	</div>

	<div class="cmplz-category cmplz-specialpurposes">
		<div class="cmplz-category-header">
			<div class="cmplz-title"></div>
			<div class='cmplz-always-active'><?php _e('Always active', 'complianz-gdpr') ?></div>
		</div>
	</div>

</div>
