<div class='cmplz-graph-container'>
	<canvas class="cmplz-graph" ></canvas>
</div>
