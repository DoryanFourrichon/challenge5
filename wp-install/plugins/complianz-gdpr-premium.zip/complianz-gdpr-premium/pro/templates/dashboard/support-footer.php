<div class="item-footer">
	<div>
		<div class="cmplz-footer-contents">
			<input type="submit" class="button button-secondary" href="https://complianz.io/support" value="<?php echo _e("Send", "complianz-gdpr") ?>">
			</form><?php //closing form element for body form ?>
		</div>
	</div>
</div>
