<?php

namespace ACP\Column\Media;

use ACP;

/**
 * @since 4.0
 */
class AuthorName extends ACP\Column\Post\AuthorName {

}