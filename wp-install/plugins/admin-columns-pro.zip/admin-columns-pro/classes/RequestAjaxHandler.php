<?php

namespace ACP;

interface RequestAjaxHandler {

	/**
	 * @return void
	 */
	public function handle();

}