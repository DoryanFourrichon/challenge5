=== Dynamic Plugins ===
Contributors: Pilot'in
Requires at least: 5.0 or higher
Tested up to: 5.8
Requires PHP: 5.6
Stable tag: 1.3.2
License: GPL v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Dashboard Client Pilot'in

