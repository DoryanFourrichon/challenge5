<?php
/* Prohibit direct script loading */
defined('ABSPATH') || die('No direct script access allowed!');
?>
<div id="advanced" class="tab-content">
    <div class="content-box content-wpmf-advanced">
        <div class="ju-settings-option">
            <div class="wpmf_row_full">
            </div>
        </div>
    </div>
</div>
