<?php
/* Prohibit direct script loading */
defined('ABSPATH') || die('No direct script access allowed!');
?>
<div style="margin: 0; float: left">
    <?php \Joomunited\WPMediaFolder\Jutranslation\Jutranslation::getInput(); ?>
</div>

