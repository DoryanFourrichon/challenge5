<div class="wpmf_avada_select_images_wrap">
    <button class="button wpmf_avada_select_images" type="button"><?php esc_html_e('Select Images', 'wpmf') ?></button>
    <div class="wpmf-fusion-images"></div>
</div>