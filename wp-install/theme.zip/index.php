<?php
get_header();

if (function_exists('the_pip_content')) {
    the_pip_content();
}

get_footer();
