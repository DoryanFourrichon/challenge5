# WYSIWYG Col

[Notion link](https://www.notion.so/wysiwyg-col-nemo-555104f58428446aad3b7b7949369545)
