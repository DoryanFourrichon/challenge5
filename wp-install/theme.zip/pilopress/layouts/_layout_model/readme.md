# Section title - Collection name

---

## Elements
**The content of the section with links to variables** _(Added by designers)_ :  
- [**`WYSIWYG`**](https://docs.google.com/document/d/1DqcX7UPeJO3Pz7VV5E9wAu5o3n9rjypl8GCNU7uwJW4/edit#heading=h.3b4k1jo0wm46)
- [**`Card`**](https://docs.google.com/document/d/1DqcX7UPeJO3Pz7VV5E9wAu5o3n9rjypl8GCNU7uwJW4/edit#heading=h.y01p61mva7ew) _(change this)_
- [**`WYSIWYG`**](https://docs.google.com/document/d/1DqcX7UPeJO3Pz7VV5E9wAu5o3n9rjypl8GCNU7uwJW4/edit#heading=h.3b4k1jo0wm46)

---

## Options
**List here the options of the section** _(Added by designers)_ :  
_ex: Number of cards displayed: `2, 3, 4, 5`_  
- Option: `value` _(change this)_

---  

## Interaction
**Describe the interaction with the section**  _(Added by designers)_ :  
_ex: `You can click the card and it redirects to the single.`_  
- Interaction type _(change this)_

---  

## Style variables
**The name of a variable contains the element to style and it's property**  
_(Added by developers, taken from Zeplin)_:  
_ex: `section-background-color: bg-primary`_  

---  

## Responsive
**Adaptation mobile link**  _(Added by designers)_ :  
- [URL](https://www.figma.com/file/9sFNXmLVL7ODsh6Vl0awGx/%F0%9F%8C%8A-PiloPress-Library-V2?node-id=661%3A21331)
