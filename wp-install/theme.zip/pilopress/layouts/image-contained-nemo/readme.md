# Image contained

[Notion link](https://www.notion.so/image-contained-nemo-d03b1840b43147678e832b916822ade2)
